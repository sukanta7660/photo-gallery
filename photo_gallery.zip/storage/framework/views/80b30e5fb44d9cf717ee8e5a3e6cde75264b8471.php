<?php $__env->startSection('title'); ?>
    <?php echo e($album->title); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12 text-center">
                <h3 class="mt-3 text-danger"><?php echo e($album->title); ?></h3>
                <hr>
            </div>
        </div>
        <?php if( $count > 0 ): ?>
        <div class="row mt-5 mb-5">
            <?php $__currentLoopData = $table; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="gallery">
                        <a href="#">
                            <img src="<?php echo e(asset('public/uploads/gallery/'.$row->images)); ?>" alt="Northern Lights" width="600" height="400">
                        </a>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <?php else: ?>
            <div class="row">
                <div class="col-md-12">
                    <h1 class="text-center">There Are No Photos In this Album</h1>
                </div>
            </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /* F:\php\htdocs\photo-gallery\resources\views/gallery_page.blade.php */ ?>