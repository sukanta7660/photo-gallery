<nav class="navbar navbar-expand-lg navbar-light bg-light">
    <a class="navbar-brand" href="<?php echo e(action('MainController@index')); ?>">Photo Gallery</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarText">
        <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
                <a class="nav-link" href="<?php echo e(action('MainController@index')); ?>">Home <span class="sr-only">(current)</span></a>
            </li>
            <?php if(isset(Auth::user()->email)): ?>
            <li class="nav-item">
                <a class="nav-link" href="#"><?php echo e(Auth::user()->name); ?></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="#" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Log Out</a>
            </li>
            <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                <?php echo e(csrf_field()); ?>

            </form>
            <?php else: ?>
            <li class="nav-item">
                <a class="nav-link" href="<?php echo e(route('login')); ?>">Log In</a>
            </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /* F:\php\htdocs\photo-gallery\resources\views/shared/header.blade.php */ ?>