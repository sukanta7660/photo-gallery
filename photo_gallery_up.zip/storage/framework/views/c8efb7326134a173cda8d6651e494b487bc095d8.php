<footer class="container">
    <div class="row">
        <div class="col-md-12 p-5 text-center">
            <p>&copy; <?php echo e(date('Y')); ?> <span style="color: midnightblue;">KnightRider7660</span></p>
        </div>
    </div>
</footer>
<?php /* F:\php\htdocs\photo-gallery\resources\views/shared/footer.blade.php */ ?>