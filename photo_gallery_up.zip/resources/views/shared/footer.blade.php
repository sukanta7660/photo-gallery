<footer class="container">
    <div class="row">
        <div class="col-md-12 p-5 text-center">
            <p>&copy; {{date('Y')}} <span style="color: midnightblue;">KnightRider7660</span></p>
        </div>
    </div>
</footer>